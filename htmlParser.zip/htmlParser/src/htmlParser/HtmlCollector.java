package htmlParser;

import java.io.IOException;
import java.util.ArrayList;
//import java.util.logging.Level;
//import java.util.logging.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
//import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

public class HtmlCollector {
	
	private static ArrayList<ArrayList<String>> returnTab = new ArrayList<ArrayList<String>>();

	public static void main(String[] args) {

		boolean mixedColumns;
		
//		int dateFromPosit;
//		int dateToPosit;
//		int eventPosit;
		boolean dateFrom;
		boolean dateTo;
		boolean event;

		try {
//LOCAL FILES
//			Document doc = Jsoup.parse("tableasd.html/asdqwe");
//HTTP/HTTPS URL
			Document doc = Jsoup.connect("http://www.tutorialspoint.com/html/html_tables.htm").get();
			Element table;
			Elements th;
			System.out.println(Jsoup.parse("table.ht ml"));
//			System.out.println(doc.select("table").get(0) + "\n");
//			System.out.println(doc.select("table").get(0).select("tr").get(0).childNode(1).childNode(0));
			
//t jumper
			for ( int tI = 0 ; ; tI++ ) {

//POSTIONS 0-2
//			dateFromPosit = 3;
//			dateToPosit = 3;
//			eventPosit = 3;
			dateFrom = false;
			dateTo = false;
			event = false;
					
			mixedColumns = false;

								
				table = doc.select("table").get(tI);
				th = table.select("th");
				if (th.size() == 0)
					mixedColumns = true;
//th jumper
				for (int i = 0 ; i < th.size() ; i++) {
					System.out.println("     i : " + i + "\nmixCol : " + mixedColumns);
					if (mixedColumns) { break; }
					
//checking whether those are table headers we want (namely: name, salary)
					switch (th.get(i).childNode(0).toString().toLowerCase()) {
					
					case "date from" :
						if (!dateFrom) { //check whether there is already a header named "date from"
							System.out.println("    gotName");
//							dateFromPosit = i;
							dateFrom = true;
						} else { System.out.println("RepeatedName"); mixedColumns = true; }
						break;
					
					case "date to" :
						if (!dateTo) { //check whether there is already a header named "date to"
							System.out.println("   gotSalary");
//							dateToPosit = i;
							dateTo = true;
						} else { System.out.println("RepeatedSalary"); mixedColumns = true; }
						break;
					
//					case "event" :
//						if (!event) { //check whether there is already a header named "event"
//							System.out.println("   gotSalary");
//							eventPosit = i;
//							event = true;
//						} else { System.out.println("RepeatedSalary"); mixedColumns = true; }
//						break;
						
					default :
						mixedColumns = true;
						System.out.println("Not Wanted Columns");
					}
				}

				System.out.println("-------" + (tI+1) + "--------\n");
				
//SPISANIE DANYCH DO TABELI WYJ�CIOWEJ					

				if (!mixedColumns) { 
					
					Elements tr = table.select("tr");
					ArrayList<String> rowTable = new ArrayList<String>();
					for (int row = 0 ; row < table.select("tr").size() ; row++) {
						System.out.println("row : " + row);
						for (int col = 0 ; col < 3 ; col++) {
							rowTable.add(new String(tr.get(row).childNode((1+col)*2-1).childNode(0).toString()));
						}
						returnTab.add(rowTable);
//strasznie g�upie czyszczenie TABELI LINIJKI
						rowTable = new ArrayList<String>();
					}
					
//Check sending order of the table headers
//					if (dateFromPosit > dateToPosit)
//						if (dateToPosit > eventPosit){}
							
					
					
					break;
				}

				System.out.println("WTFin");
				
			}	
			System.out.println("WTFout");
		} 
		//IOException is not for local files
		catch (IOException e) 					{ System.out.println("Input Output Exception"); }
		catch (IndexOutOfBoundsException e) 	{ System.out.println("End of Tables"); }
		
		System.out.println(returnTab);
		
	}
	
	public String returnString() { return returnTab.toString(); }
	
}
