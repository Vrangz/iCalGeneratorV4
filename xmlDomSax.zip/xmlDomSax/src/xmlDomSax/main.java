package xmlDomSax;

import org.xml.sax.*;
import org.w3c.dom.*;

import java.util.ArrayList;
import java.util.Scanner;

import javax.xml.parsers.*;

public class main {
	
	private static String returningString;
	
	public static void main(String[] args){
		System.out.println("Podaj nazwe pliku xml");
		Document xmlDoc = getDocument(getFileName());
		NodeList listOfEvents = xmlDoc.getElementsByTagName("event");
		String[] elements = {"dateStart" , "dateEnd" , "title"};
		returningString = getElement(listOfEvents, elements);
	}

	private static String getFileName() {
		return new Scanner(System.in).nextLine();
	}

	private static Document getDocument(String docString) {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					
//			factory.setIgnoringComments(true);
//			factory.setIgnoringElementContentWhitespace(true);
			factory.setValidating(true);
			
			DocumentBuilder builder = factory.newDocumentBuilder();
			return builder.parse(new InputSource(docString));	
		}
		catch(Exception ex) {System.out.println(ex.getMessage());}
		return null;
	}
	
	private static String getElement(NodeList listOfEvents, String[] elements) {
		String temp = "";
		try {
			temp="[";
			for(int i = 0 ; i < listOfEvents.getLength() ; i++) {

				Node eventNode = listOfEvents.item(i);
				Element showElement = (Element)eventNode;
				
				NodeList dateStartList = showElement.getElementsByTagName(elements[0]);
				NodeList dateEndList = showElement.getElementsByTagName(elements[1]);
				NodeList titleList = showElement.getElementsByTagName(elements[2]);
				
				Element dateStartElement = (Element)dateStartList.item(0);
				Element dateEndElement = (Element)dateEndList.item(0);
				Element titleElement = (Element)titleList.item(0);
				
				NodeList elementList0 = dateStartElement.getChildNodes();
				NodeList elementList1 = dateEndElement.getChildNodes();
				NodeList elementList2 = titleElement.getChildNodes();

				temp = temp + "[" + ((Node)elementList2.item(0)).getNodeValue().trim() + ", " +
						((Node)elementList0.item(0)).getNodeValue().trim() + ", " +
						((Node)elementList1.item(0)).getNodeValue().trim() + "]";
				if ( i<listOfEvents.getLength()-1 ) {
					temp = temp +", ";
				}
				
			}
			temp = temp + "]";
			System.out.println(temp);
		}
		catch(Exception ex) {System.out.println(ex.getMessage());}
		
		return temp;
	}
	
	private String returnString() { return returningString; }
}
